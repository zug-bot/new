# Inspiration & References (Study-only)
- Octopath Traveler: layered 2.5D look, depth-of-field, lighting, HD-2D style.
- Triangle Strategy: isometric tactics environments and character scale.
- Sekiro: precise, timing-based parry combat; posture mechanics (consider adapting).

> Replace placeholder assets with your own licensed sprites.
> Consider building normal maps for 2D sprites to enhance lighting in PixiJS.
